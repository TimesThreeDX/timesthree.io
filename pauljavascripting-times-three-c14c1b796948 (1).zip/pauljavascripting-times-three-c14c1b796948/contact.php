<?php
/**
 * Template Name: Contact
 * @package WordPress
 */
get_header(); ?>

<!--START PAGE CONTENT-->

<div class="services-page">
contact
</div>

<!--END PAGE CONTENT-->

<?php get_footer(); ?>